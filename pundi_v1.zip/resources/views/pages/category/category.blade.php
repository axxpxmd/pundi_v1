@extends('layouts.app')
@section('content')
@include('masterPages.headers.header')
<div class="container m-t-15">
    <div class="m-0">
        <i class="fa fa-home"></i>
        <a class="m-l-8 m-r-8 f-red fs-14 non-hover f-orange hover-blk" href="{{ route('/') }}">
            <span>Home</span>
        </a>
        <i class="fa fa-angle-right"></i>
        <a class="m-l-8 m-r-8 f-red fs-14 non-hover f-orange" href="{{ route('category',str_slug($category->n_category)) }}">
            <span>{{ $category->n_category }}</span>
        </a>
    </div>
    <div class="m-t-10">
        <div class="-mb-13">
            <i class="fas fa-angle-up fa-lg arrow"></i>
        </div>
        <span class="fs-18 m-l-15 kategori-title"> 
            KATEGORI : {{ $category->n_category }}
        </span>
    </div>
    <div class="m-t-15">   
        @foreach ($subCategory as $i)
        <span class="bdr-5 fs-11 f-b m-r-10 sub-kategori-card">
            <a href="sub-kategori" class="hover-blk">{{ $i->n_sub_category}}</a>
        </span>
        @endforeach
    </div>
</div>
<section class="blog_area section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mb-5 mb-lg-0">
                <div class="blog_left_sidebar">
                    @foreach ($articles as $i)
                    <div class="row m-b-30">
                        <div class="col-sm-6">
                            <img class="bdr-5 m-b-10 img-circular" src="{{ config('app.ftp_src').'images/artikel/'.$i->image }}" width="350" height="350" alt="photo">
                        </div>
                        <div class="col-sm-6">
                            <span class="bdr-5 fs-11 f-b sub-kategori-card">
                                <a href="sub-kategori" class="hover-blk">{{ $i->sub_category->n_sub_category }}</a>
                            </span>
                            <p class="fs-19 f-b f-blk m-t-10">
                                <a href="artikel" class="text-black judul-hover">{{ $i->title }}</a>
                            </p>
                            <div class="-mt-10 text-grey">
                                <i class="fa fa-user mr-1"></i>
                                <a href="{{ route('other-user', str_slug($i->user->name)) }}" class="judul-hover text-grey fs-13">
                                    {{ $i->user->name }}
                                </a>
                                <i class="fas fa-clock mr-1 ml-3"></i>
                                <span class="fs-13">{{ substr($i->created_at,0,10) }}</span>
                            </div>
                            <div class="text-justify mt-2">
                                {{  substr(strip_tags(str_replace(["&nbsp;", "&rdquo;", "&ldquo;", "&rsquo;", "&hellip;"],' ',$i->contens)),0,400) }} […]
                            </div>
                            <a href="artikel" class="f-blk fs-13 f-b m-t-5 judul-hover">
                                <span>READ MORE</span>
                                <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                    @endforeach
                    <div>
                        {{ $articles->links() }}
                    </div>
                </div>
            </div>
            @include('masterPages.sideBar')
        </div>
    </div>
</section>
@include('masterPages.footer')
@endsection

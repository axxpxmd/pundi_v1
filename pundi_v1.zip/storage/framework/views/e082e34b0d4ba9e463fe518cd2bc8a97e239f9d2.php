<!-- Alert Errors -->
<?php if(session()->has('success')): ?>
<div class="alert alert-success alert-dismissible fade show text-center bdr-5 col-md-12 container" role="alert">
    <?php echo e(session('success')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php endif; ?>
<!-- Alert Errors -->
<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
    <strong>Whoops Error!</strong>&nbsp;
    <span>You have <?php echo e($errors->count()); ?> error</span>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?> 
<?php /**PATH E:\xampp\htdocs\focusing\pundi_v1\resources\views/masterPages/alerts.blade.php ENDPATH**/ ?>
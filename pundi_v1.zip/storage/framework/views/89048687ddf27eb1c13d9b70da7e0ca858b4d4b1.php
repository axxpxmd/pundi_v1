
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('masterPages.headers.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="blog_area section-padding" style="background-color: #F7F7F7">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mb-5 mb-lg-0">
                <div class="blog_left_sidebar">
                    <div class="card no-b">
                        <div class="card-body">
                            <div class="text-center">
                                <img class="rounded-circle img-circular" src="<?php echo e(config('app.ftp_src').'images/ava/'.$user->photo); ?>" height="100" width="100"  alt="Photo profile">
                                <p class="fs-22 font-weight-bold text-black mt-3"><?php echo e($user->name); ?>

                                    <?php if($countArticle < 5): ?>
                                    <i style="color: #945d41" class="fa fa-medal ml-1"></i>
                                    <?php elseif($countArticle >= 5 && $countArticle <= 10): ?>
                                    <i style="color: #C0C0C0" class="fa fa-medal ml-1"></i>
                                    <?php elseif($countArticle >= 10): ?>
                                    <i style="color: #ffc60b" class="fa fa-medal ml-1"></i>
                                    <?php endif; ?>
                                </p>
                                <p class="text-black -mt-10">“ <?php echo e($user->bio); ?> ”</p>
                                <div class="mb-2 mt-n2">
                                    <?php if($user->facebook != null): ?>
                                    <a class="f-blk judul-hover" href="https://web.facebook.com/<?php echo e($user->facebook); ?>" target="blank">
                                        <i class="fa fa-facebook-square fa-lg mr-2"></i>
                                    </a>
                                    <?php endif; ?>
                                    <?php if($user->twitter != null): ?>
                                    <a class="f-blk judul-hover" href="https://twitter.com/<?php echo e($user->twitter); ?>" target="blank">
                                        <i class="fa fa-twitter-square fa-lg mr-2"></i>
                                    </a>
                                    <?php endif; ?>
                                    <?php if($user->instagram != null): ?>
                                    <a class="f-blk judul-hover" href="https://www.instagram.com/<?php echo e($user->instagram); ?>" target="blank"> 
                                        <i class="fab fa-instagram-square fa-lg"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="mt-3">
                                <ul class="nav nav-tabs nav-justified" id="myTab" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active text-black judul-hover" id="home-tab" data-toggle="tab" href="#home" role="tab">Artikel</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link text-black judul-hover" id="profile-tab" data-toggle="tab" href="#profile" role="tab">Komentar</a>
                                    </li>
                                </ul>
                                <div class="tab-content" id="myTabContent">
                                    <div class="tab-pane fade show active" id="home" role="tabpanel">
                                        <?php if($article->count() != 0): ?>
                                        <table class="table mt-2 table-striped">
                                            <thead>
                                                <tr>
                                                    <th width="30" style="border-bottom: none">#</th>
                                                    <th style="border-bottom: none">Judul</th>
                                                    <th width="60">Dilihat</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td scope="row"><?php echo e($index+1); ?></td>
                                                    <td><a href="artikel" class="text-black text-decoration-none judul-hover"><?php echo e($i->title); ?></a></td>
                                                    <td><?php echo e($i->views); ?></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        <div>
                                            <?php echo e($article->links()); ?>

                                        </div>
                                        <?php else: ?>
                                        <div class="mt-2">
                                            <img class="mx-auto d-block" src="<?php echo e(asset('images/article-not-found.png')); ?>" width="180" alt="">
                                            <p class="text-center font-weight-bold fs-14">Belum ada artikel</p>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="tab-pane fade" id="profile" role="tabpanel">
                                        <?php if($comment->count() != 0): ?>
                                            <?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="row">
                                                <div class="col-md-12 p-3">
                                                    <span class="font-weight-bold"><?php echo e($user->name); ?></span>
                                                    <span class="ml-1">mengomentari</span>
                                                    <span class="font-weight-bold fs-14 ml-1"><?php echo e($i->article->title); ?></span>
                                                    <br>
                                                    <span class=""><?php echo e($i->content); ?></span>
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <div class="mt-2">
                                            <img class="mx-auto d-block" src="<?php echo e(asset('images/comment-not-found.png')); ?>" width="180" alt="">
                                            <p class="text-center font-weight-bold fs-14">Belum ada komentar</p>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('masterPages.sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</section>
<?php echo $__env->make('masterPages.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\focusing\pundi_v1\resources\views/pages/profiles/otherUser/otherProfile.blade.php ENDPATH**/ ?>
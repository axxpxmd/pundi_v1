<section class="whats-news-area m-t-30">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 -mt-10">
                <div class="row d-flex justify-content-between">
                    <div class="col-lg-3 col-md-3">
                        <div class="section-tittle">
                            <div class="-mb-13">
                                <i class="fas fa-angle-up fa-lg arrow"></i>
                            </div>
                            <span class="fs-18 m-l-15 title-card"> 
                                <?php echo e($titleCard->card2); ?>

                            </span>
                        </div>
                    </div>
                    <div class="col-lg-9 col-md-9 m-t-5">
                        <div class="properties__button">                                       
                            <nav>                                                                     
                                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                    <a class="nav-item nav-link active fs-14i text-uppercase" id="nav-home-tab" data-toggle="tab" href="#all">Semua</a>
                                    <a class="nav-item nav-link fs-14i text-uppercase" id="nav-profile-tab" data-toggle="tab" href="#card1"><?php echo e($category1->n_category); ?></a>
                                    <a class="nav-item nav-link fs-14i text-uppercase" id="nav-contact-tab" data-toggle="tab" href="#card2"><?php echo e($category2->n_category); ?></a>
                                    <a class="nav-item nav-link fs-14i text-uppercase" id="nav-last-tab" data-toggle="tab" href="#card3"><?php echo e($category3->n_category); ?></a>
                                    <a class="nav-item nav-link fs-14i text-uppercase" id="nav-Sports" data-toggle="tab" href="#card4"><?php echo e($category4->n_category); ?></a>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
                <div class="row -mt-15">
                    <div class="col-12">
                        <div class="tab-content" id="nav-tabContent">
                            <div class="tab-pane fade show active" id="all">           
                                <div class="whats-news-caption">
                                    <div class="row">
                                        <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-6 col-md-6">
                                            <div class="single-what-news m-b-30">
                                                <div class="what-img">
                                                    <img style="object-fit: cover; object-position: center" src="<?php echo e(config('app.ftp_src').'images/artikel/'.$i->image); ?>" height="300" alt="photo"">
                                                </div>
                                                <div class="what-cap">
                                                    <span class="bdr-5" style="background-color: #FEBD01; color: white">
                                                        <a href="sub-kategori" class="hover-blk"><?php echo e($i->sub_category->n_sub_category); ?></a>
                                                    </span>
                                                    <i class="fas fa-clock fa-xs m-l-10 text-grey"></i>
                                                    <span style="color: grey; margin-left: -10px"><?php echo e(substr($i->created_at, 0, 10)); ?></span>
                                                    <br>
                                                    <div style="margin-top: -10px">
                                                        <i class="fas fa-user fa-xs text-grey"></i>
                                                        <a class="judul-hover" href="<?php echo e(route('other-user', str_slug($i->user->name))); ?>">
                                                            <span class="judul-hover" style="color: grey;margin-left: -10px"><?php echo e($i->user->name); ?></span>
                                                        </a>
                                                    </div>
                                                    <h4 style="margin-top: -15px">
                                                        <a href="artikel"><?php echo e($i->title); ?></a>
                                                    </h4>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="card1">
                                <div class="whats-news-caption">
                                    <div class="row">
                                        <?php $__currentLoopData = $n_category1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-6 col-md-6">
                                            <div class="single-what-news mb-100">
                                                <div class="what-img">
                                                    <img style="object-fit: cover; object-position: center" src="<?php echo e(config('app.ftp_src').'images/artikel/'.$i->image); ?>" height="300" alt="photo"">
                                                </div>
                                                <div class="what-cap">
                                                    <span class="bdr-5" style="background-color: #FEBD01; color: white">
                                                        <a href="sub-kategori" class="hover-blk"><?php echo e($i->sub_category->n_sub_category); ?></a>
                                                    </span>
                                                    <i class="fas fa-clock fa-xs m-l-10 text-grey"></i>
                                                    <span style="color: grey; margin-left: -10px"><?php echo e(substr($i->created_at, 0, 10)); ?></span>
                                                    <br>
                                                    <div style="margin-top: -10px">
                                                        <i class="fas fa-user fa-xs text-grey"></i>
                                                        <a class="judul-hover" href="<?php echo e(route('other-user', str_slug($i->user->name))); ?>">
                                                            <span class="judul-hover" style="color: grey;margin-left: -10px"><?php echo e($i->user->name); ?></span>
                                                        </a>
                                                    </div>
                                                    <h4 style="margin-top: -15px">
                                                        <a href="artikel"><?php echo e($i->title); ?></a>
                                                    </h4>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="card2">
                                <div class="whats-news-caption">
                                    <div class="row">
                                        <?php $__currentLoopData = $n_category2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-6 col-md-6">
                                            <div class="single-what-news mb-100">
                                                <div class="what-img">
                                                    <img style="object-fit: cover; object-position: center" src="<?php echo e(config('app.ftp_src').'images/artikel/'.$i->image); ?>" height="300" alt="photo"">
                                                </div>
                                                <div class="what-cap">
                                                    <span class="bdr-5" style="background-color: #FEBD01; color: white">
                                                        <a href="sub-kategori" class="hover-blk"><?php echo e($i->sub_category->n_sub_category); ?></a>
                                                    </span>
                                                    <i class="fas fa-clock fa-xs m-l-10 text-grey"></i>
                                                    <span style="color: grey; margin-left: -10px"><?php echo e(substr($i->created_at, 0, 10)); ?></span>
                                                    <br>
                                                    <div style="margin-top: -10px">
                                                        <i class="fas fa-user fa-xs text-grey"></i>
                                                        <a class="judul-hover" href="<?php echo e(route('other-user', str_slug($i->user->name))); ?>">
                                                            <span class="judul-hover" style="color: grey;margin-left: -10px"><?php echo e($i->user->name); ?></span>
                                                        </a>
                                                    </div>
                                                    <h4 style="margin-top: -15px">
                                                        <a href="artikel"><?php echo e($i->title); ?></a>
                                                    </h4>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="card3">
                                <div class="whats-news-caption">
                                    <div class="row">
                                        <?php $__currentLoopData = $n_category3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-6 col-md-6">
                                            <div class="single-what-news mb-100">
                                                <div class="what-img">
                                                    <img style="object-fit: cover; object-position: center" src="<?php echo e(config('app.ftp_src').'images/artikel/'.$i->image); ?>" height="300" alt="photo"">
                                                </div>
                                                <div class="what-cap">
                                                    <span class="bdr-5" style="background-color: #FEBD01; color: white">
                                                        <a href="sub-kategori" class="hover-blk"><?php echo e($i->sub_category->n_sub_category); ?></a>
                                                    </span>
                                                    <i class="fas fa-clock fa-xs m-l-10 text-grey"></i>
                                                    <span style="color: grey; margin-left: -10px"><?php echo e(substr($i->created_at, 0, 10)); ?></span>
                                                    <br>
                                                    <div style="margin-top: -10px">
                                                        <i class="fas fa-user fa-xs text-grey"></i>
                                                        <a class="judul-hover" href="<?php echo e(route('other-user', str_slug($i->user->name))); ?>">
                                                            <span class="judul-hover" style="color: grey;margin-left: -10px"><?php echo e($i->user->name); ?></span>
                                                        </a>
                                                    </div>
                                                    <h4 style="margin-top: -15px">
                                                        <a href="artikel"><?php echo e($i->title); ?></a>
                                                    </h4>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="card4">
                                <div class="whats-news-caption">
                                    <div class="row">
                                        <?php $__currentLoopData = $n_category4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-6 col-md-6">
                                            <div class="single-what-news mb-100">
                                                <div class="what-img">
                                                    <img style="object-fit: cover; object-position: center" src="<?php echo e(config('app.ftp_src').'images/artikel/'.$i->image); ?>" height="300" alt="photo"">
                                                </div>
                                                <div class="what-cap">
                                                    <span class="bdr-5" style="background-color: #FEBD01; color: white">
                                                        <a href="sub-kategori" class="hover-blk"><?php echo e($i->sub_category->n_sub_category); ?></a>
                                                    </span>
                                                    <i class="fas fa-clock fa-xs m-l-10 text-grey"></i>
                                                    <span style="color: grey; margin-left: -10px"><?php echo e(substr($i->created_at, 0, 10)); ?></span>
                                                    <br>
                                                    <div style="margin-top: -10px">
                                                        <i class="fas fa-user fa-xs text-grey"></i>
                                                        <a class="judul-hover" href="<?php echo e(route('other-user', str_slug($i->user->name))); ?>">
                                                            <span class="judul-hover" style="color: grey;margin-left: -10px"><?php echo e($i->user->name); ?></span>
                                                        </a>
                                                    </div>
                                                    <h4 style="margin-top: -15px">
                                                        <a href="artikel"><?php echo e($i->title); ?></a>
                                                    </h4>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('pages.homePage.sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <hr width="100%" class="-mt-10" style="color: #ddd">
    </div>
</section><?php /**PATH E:\xampp\htdocs\focusing\pundi_v1\resources\views/pages/homePage/section3.blade.php ENDPATH**/ ?>
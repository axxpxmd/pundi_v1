<?php echo e($slot); ?>

<?php /**PATH E:\xampp\htdocs\focusing\pundi_v1\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>
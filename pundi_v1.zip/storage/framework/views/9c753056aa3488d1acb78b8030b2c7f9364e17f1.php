<?php $__env->startSection('content'); ?>
<?php echo $__env->make('masterPages.headers.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="blog_area section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mb-5 mb-lg-0">
                <div class="blog_left_sidebar">
                    <div class="container">
                        <form class="needs-validation" novalidate method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                            <p class="text-center fs-30 f-b f-blk m-b-30">Login</p>
                            <div class="form-group row">
                                <label class="col-sm-2 f-b col-form-label" for="email">E-MAIL</label>
                                <div class="col-sm-10">
                                    <input type="email" name="email" id="email" class="form-control input single-input-primary <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="example@email.com"/>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong>Email / Password salah</strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-2 f-b col-form-label" for="password">PASSWORD</label>
                                <div class="col-sm-10">
                                    <input type="password"  name="password" id="password" class="input single-input-primary <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password"/>
                                    <a href="<?php echo e(route('password.request')); ?>">
                                        <p class="f-blk text-right fs-15 f-red mt-2">Lupa password?</p>
                                    </a>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-2"></div>
                                <div class="col-sm-10">
                                    <button class="genric-btn primary bdr-5" type="submit" value="Log in">Login <i class="fa fa-arrow-right"></i></button>
                                </div>
                            </div>
                            <hr>
                            <p class="f-blk -mt-20">Belum punya akun? 
                                <a href="<?php echo e(route('register')); ?>">
                                    <u class="f-orange hover-blk">Daftar sekarang!</u>
                                </a>
                            </p>
                        </form>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('masterPages.sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</section>
<?php echo $__env->make('masterPages.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\focusing\pundi_v1\resources\views/auth/login.blade.php ENDPATH**/ ?>
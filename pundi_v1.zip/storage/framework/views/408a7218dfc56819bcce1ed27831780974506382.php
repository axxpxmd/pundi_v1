<?php $__env->startSection('content'); ?>
<?php echo $__env->make('masterPages.headers.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="blog_area section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mb-5 mb-lg-0">
                <div class="blog_left_sidebar">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success alert-dismissible fade show text-center bdr-5 col-md-12 container" role="alert">
                        <p class="text-center m-auto">
                            Cek email Anda untuk mengganti password.
                        </p>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php endif; ?>
                    <form class="needs-validation" action="<?php echo e(route('password.email')); ?>" method="POST" novalidate>
                        <?php echo csrf_field(); ?>
                        <p class="text-center fs-30 f-b f-blk">Lupa Password</p>
                        <p class="text-center m-t-20 f-blk m-b-30">Masukan E-mail untuk mengganti password</p>
                        <div class="mt-10 form-group row">
                            <label class="col-sm-2 f-b col-form-label" for="email">EMAIL</label>
                            <div class="col-sm-10">
                                <input type="email" name="email" class="form-control input single-input-primary <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required/>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong>E-mail belum terdaftar</strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-2"></div>
                            <div class="col-sm-10">
                                <button class="genric-btn primary bdr-5">Kirim</button>
                            </div>
                        </div>
                        <hr>
                    </form>
                </div>
            </div>
            <?php echo $__env->make('masterPages.sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</section>
<?php echo $__env->make('masterPages.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\focusing\pundi_v1\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <!-- Header -->
    <?php echo $__env->make('masterPages.headers.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Section 1 -->
    <?php echo $__env->make('pages.homePage.section1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Section 2 -->
    <?php echo $__env->make('pages.homePage.section2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Section 3 -->
    <?php echo $__env->make('pages.homePage.section3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Section 4 -->
    <?php echo $__env->make('pages.homePage.section4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <!-- Section 5 -->
     <?php echo $__env->make('pages.homePage.section5', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Footer -->
    <?php echo $__env->make('masterPages.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\focusing\pundi_v1\resources\views/home.blade.php ENDPATH**/ ?>